public enum instructioEnum 
{
    A_instruction,
    L_instruction,
    C_instruction;
}
